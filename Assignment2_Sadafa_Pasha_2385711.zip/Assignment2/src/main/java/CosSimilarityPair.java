public class CosSimilarityPair {
    private String strWord1;
    private String strWord2;
    private double doubCS;
    private Vector vecVector;



    public CosSimilarityPair(String _word1, String _word2, double _cosinesimilarity) {
        strWord1 = _word1;
        strWord2 = _word2;
        doubCS = _cosinesimilarity;



        //TODO Task 3.1
    }



    public CosSimilarityPair(Vector _vector, String _word2, double _cosinesimilarity) {
        vecVector = _vector;
        strWord2 = _word2;
        doubCS = _cosinesimilarity;
        //TODO Task 3.2
    }




    public String getWord1() {
        return strWord1 ;
        //TODO Task 3.3



    }



    public String getWord2() {
        //TODO Task 3.4
        return strWord2 ;
    }



    public double getCosineSimilarity() {
        //TODO Task 3.5
        return doubCS ;
    }





    public void setCosineSimilarity(double _cs) {
        doubCS = _cs;
        //TODO Task 3.6
    }



    public void setWord1(String _word) {



        this.strWord1 =  _word;
        //TODO Task 3.7
    }



    public void setWord2(String _word) {
        this.strWord2 = _word;
        //TODO Task 3.8
    }



    public Vector getVector() {
        return  vecVector;
        //TODO Task 3.9



    }



    public void setVector(Vector _vector) {



        vecVector = _vector;
        //TODO Task 3.10
    }



}