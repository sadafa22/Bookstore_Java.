import java.util.Arrays;

public class Vector<MyClass> {

    // Attributes
    private double[] doubElements;
    private boolean length;

    // Constructor
    public Vector(double[] _elements) {
        this.doubElements = _elements;
    }

// Methods

    // function to get element at index
    public double getElementatIndex(int _index) {
        if (_index < 0 || _index >= this.doubElements.length) {
            return -1;
        } else {
            return this.doubElements[_index];
        }
    }

    // function to set element at index
    public void setElementatIndex(double _value, int _index) {
// if index is out of bounds
        if (_index < 0 || _index >= this.doubElements.length) {
            this.doubElements[this.doubElements.length - 1] = _value;
        } else {
// return element at index
            this.doubElements[_index] = _value;
        }
    }

    // function to get all elements
    public double[] getAllElements() {
        return this.doubElements;
    }

    // function to get vector size
    public int getVectorSize() {
        return this.doubElements.length;
    }

    public Vector reSize(int _size) {
        //TODO Task 1.6
        if (_size == this.doubElements.length || _size <= 0) {
            return this;
        }



        double[] newElements = new double[_size];
        int numElementsToCopy = Math.min(_size, this.doubElements.length);
        for (int i = 0; i < numElementsToCopy; i++) {
            newElements[i] = this.doubElements[i];
        }
        for (int i = numElementsToCopy; i < _size; i++) {
            newElements[i] = -1.0;
        }



        return new Vector(newElements);



    }
    public Vector add(Vector _v) {
        //TODO Task 1.7
        Vector v1 = this;
        Vector v2 = _v;
        if (v1.getVectorSize() < v2.getVectorSize()) {
            v1 = v1.reSize(v2.getVectorSize());
        } else {
            v2 = v2.reSize(v1.getVectorSize());
        }



        double[] elements = new double[v1.getVectorSize()];
        for (int i = 0; i < elements.length; i++) {
            elements[i] = v1.getElementatIndex(i) + v2.getElementatIndex(i);
        }
        return new Vector(elements);
    }



    public Vector subtraction(Vector _v) {
        //TODO Task 1.8
        Vector v1 = this;
        Vector v2 = _v;
        if (v1.getVectorSize() < v2.getVectorSize()) {
            v1 = v1.reSize(v2.getVectorSize());
        } else {
            v2 = v2.reSize(v1.getVectorSize());
        }



        double[] elements = new double[v1.getVectorSize()];
        for (int i = 0; i < elements.length; i++) {
            elements[i] = v1.getElementatIndex(i) - v2.getElementatIndex(i);
        }
        return new Vector(elements);
    }


    public double dotProduct(Vector _v) {
        //TODO Task 1.9
        // Make sure both vectors have the same size
        // if length of _v is bigger than current length
        if (_v.getVectorSize() > this.doubElements.length) {
            // call reSize method
            this.doubElements = this.reSize(_v.getVectorSize()).getAllElements();
        } else {
            // call reSize method
            _v.reSize(this.doubElements.length);
        }
        // create new array
        double[] newVector = new double[this.doubElements.length];
        // loop through new array
        for (int i = 0; i < newVector.length; i++) {
            // assign values to new array
            newVector[i] = this.doubElements[i] * _v.getElementatIndex(i);
        }
        // compute dot product
        double dotProduct = 0;
        for (int i = 0; i < newVector.length; i++) {
            dotProduct += newVector[i];
        }
        // return dot product
        return dotProduct;
    }

    public double cosineSimilarity(Vector _v) {
        //TODO Task 1.10
       if(_v.getVectorSize()>this.getVectorSize()){
           this.doubElements=this.reSize((_v).getVectorSize()).getAllElements();
           }else if (_v.getVectorSize()<this.getVectorSize()){
               _v= _v.reSize(this.getVectorSize());
           }
       double[] Array=new double[_v.getVectorSize()];
       for(int i=0;i< _v.getVectorSize();i++);
        int i = 0;
        {
           Array[i]=this.doubElements[i]- _v.doubElements[i];
        }
           double top=this.dotProduct(_v);
           double X=0;
           double Y=0;
                   for(int x=0;i<this.getVectorSize();i++){
                       X=X+Math.pow(this.doubElements[i],2);
                       Y=Y+Math.pow(_v.getElementatIndex(i),2);
                   }
                   X=Math.sqrt(X);
                   Y=Math.sqrt(Y);
                   double answer=top/(X*Y);
                   return answer;
           }






    @Override
    public boolean equals(Object _obj) {
        Vector v = (Vector) _obj;
        boolean boolEquals = true;
        //TODO Task 1.11
        return boolEquals;
    }


    @Override
    public String toString() {
        StringBuilder mySB = new StringBuilder();
        for (int i = 0; i < this.getVectorSize(); i++) {
            mySB.append(String.format("%.5f", doubElements[i])).append(",");
        }
        mySB.delete(mySB.length() - 1, mySB.length());
        return mySB.toString();
    }
}
